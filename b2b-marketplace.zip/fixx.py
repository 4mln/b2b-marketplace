# migrate_all_warnings.py
import os
import re

BASE_DIR = "./plugins"  # adjust to your project root

def migrate_file(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()

    original_content = content

    # 1. Pydantic Config migration
    # Matches 'class Config:' and indented lines below it
    config_pattern = re.compile(r"class Config:\n((?:\s+.*\n)+)")
    content = config_pattern.sub(lambda m: f"model_config = ConfigDict(\n{m.group(1)})\n", content)

    # 2. @validator → @field_validator
    content = re.sub(r"@validator\(", "@field_validator(", content)

    # 3. FastAPI Query regex → pattern
    content = re.sub(r"regex\s*=", "pattern=", content)

    # 4. httpx AsyncClient(app=app) → transport style
    content = re.sub(
        r"AsyncClient\(\s*app\s*=\s*(\w+)\s*\)",
        r"AsyncClient(transport=ASGITransport(app=\1))",
        content
    )

    if content != original_content:
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"[Migrated] {file_path}")

def migrate_project():
    for root, dirs, files in os.walk(BASE_DIR):
        for file in files:
            if file.endswith(".py"):
                migrate_file(os.path.join(root, file))

if __name__ == "__main__":
    migrate_project()
