to run test :
PS C:\b2b-marketplace> docker compose exec api pytest -v /code/tests/plugins/full_plugins_test.py