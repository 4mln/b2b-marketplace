a b2b platform where:

1-every one can visit a free product list (not the seller info and only products).
2-